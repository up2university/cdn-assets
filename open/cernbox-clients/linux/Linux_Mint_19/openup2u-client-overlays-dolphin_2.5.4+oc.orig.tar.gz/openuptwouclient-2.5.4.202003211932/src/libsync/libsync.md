\defgroup libsync The sync library

The sync library
================

