Doc Build Convenience Scripts
=============================

* ``htmlhelp.sh``: A script to install Microsoft HTML Workshop on Linux or Mac OS using Wine, along with some dependencies.
* ``htmlhelp.reg``: Registry file to override some DLLs with their native version and set the right Windows version.

Those files have been taken from the `HTML Help Project`_.

License
-------

The HTML Help Project has licensed_ its software under LGPLv2.1 terms

.. _HTML Help Project: http://code.google.com/p/htmlhelp/wiki/HHW4Wine
.. _licensed: https://code.google.com/p/htmlhelp/source/browse/trunk/pyhtmlhelp/COPYING
