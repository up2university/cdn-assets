# qtmacgoodies

A couple of additional Qt widgets/objects to make Qt apps look more native on Mac OS X.

## License

See LICENSE file.
