.. _contents:

ownCloud Desktop Client Manual
==============================

.. toctree::
   :maxdepth: 2

   introduction
   installing
   navigating
   conflicts
   advancedusage
   autoupdate
   building 
   architecture
   troubleshooting
   faq
   glossary

