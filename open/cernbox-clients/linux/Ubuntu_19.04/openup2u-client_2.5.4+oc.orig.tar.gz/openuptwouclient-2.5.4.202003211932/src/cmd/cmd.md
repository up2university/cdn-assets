\defgroup cmd The command line client

The command line client
=======================
