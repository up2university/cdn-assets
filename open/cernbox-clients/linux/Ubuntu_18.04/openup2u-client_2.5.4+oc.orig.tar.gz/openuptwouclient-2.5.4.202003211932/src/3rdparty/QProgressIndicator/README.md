## Description

The QProgressIndicator class lets an application display a progress indicator to show that a lengthy task is under way.
Will work at any size.

<img src="https://raw.github.com/mojocorp/QProgressIndicator/master/screen-capture-1.png" >
<img src="https://raw.github.com/mojocorp/QProgressIndicator/master/screen-capture-2.png" >

## Dependency
Qt 4.4.x.

## License

MIT
