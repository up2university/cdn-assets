The GUI Client
==============

\defgroup gui The GUI client

